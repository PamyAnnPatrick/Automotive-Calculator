﻿using System.Text.RegularExpressions;
using System.Windows;

namespace Automobile
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        VM vm = new VM();
        private const string REG_NUM = "[0-9]+";
        private const string REG_DOUBLE = "[0-9.]+";
        public MainWindow()
        {
            InitializeComponent();
            DataContext = vm;
        }
        private void BtnCalculate_Click(object sender, RoutedEventArgs e)
        {
            vm.Calculate();
        }
        private void BtnReset_Click(object sender, RoutedEventArgs e)
        {
            vm.ClearAll();
        }
        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            vm.Save();
        }
        private void BtnPrint_Click(object sender, RoutedEventArgs e)
        {
            vm.Print(gridResult);
        }
        private void InputInt_PreviewTextInput(object sender, System.Windows.Input.TextCompositionEventArgs e)
        {
            Regex r = new Regex(REG_NUM);
            e.Handled = !r.IsMatch(e.Text);
            if (e.Text != "0")
                vm.CheckOtherService();           
        }
        private void InputDecimal_PreviewTextInput(object sender, System.Windows.Input.TextCompositionEventArgs e)
        {
            Regex r = new Regex(REG_DOUBLE);
            e.Handled = !r.IsMatch(e.Text);
            if (e.Text != "0")
                vm.CheckOtherService();
        }
        private void ChkNonService_Unchecked(object sender, RoutedEventArgs e)
        {
            vm.ClearOther();
            vm.ClearTaxAndTotal();
        }
    }
}
