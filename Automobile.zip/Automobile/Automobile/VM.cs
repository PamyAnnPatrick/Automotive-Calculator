﻿using Microsoft.Win32;
using System;
using System.ComponentModel;
using System.IO;
using System.Runtime.CompilerServices;
using System.Windows.Controls;

namespace Automobile
{
    class VM : INotifyPropertyChanged
    {
        #region Variable declarations
        enum charges
        {
            OIL_CHARGES = 26,
            LUBE_CHARGES = 18,
            RADIATOR_CHARGES = 30,
            TRANSMISSION_CHARGES = 80,
            INSPECTION_CHARGES = 15,
            MUFFLER_CHARGES = 100,
            TIRE_CHARGES = 20,
            LABOR_CHARGES = 20
        }
        const int SINGLE_WIDTH = 500;
        const int DOUBLE_WIDTH = 610;
        const int SINGLE_HEIGHT = 580;
        const int DOUBLE_HEIGHT = 540;
        const decimal TAX_RATE = 0.06M;
        private int titleWidth = DOUBLE_WIDTH;
        private int titleHeight = DOUBLE_HEIGHT;
        private int noOfHours;
        private decimal partCharges;
        private bool oilChange;
        private bool lubeJob;
        private bool radiator;
        private bool inspection;
        private bool transmission;
        private bool muffler;
        private bool tire;
        private bool otherService;
        private bool gridResultVis = false;
        private bool gridSelectVis = true;
        private string partChargesVal;
        private string partTotalVal;
        private string labourTotalVal;
        private string oilLubeVal;
        private string flushChargesVal;
        private string miscChargesVal;
        private string otherChargesVal;
        private string labourVal;
        private string labourText;
        private string totalChargesVal;
        private string taxChargesVal;
        public int TitleWidth { get { return titleWidth; } set { titleWidth = value; onChange(); } }
        public int TitleHeight { get { return titleHeight; } set { titleHeight = value; onChange(); } }
        public bool OilChange
        {
            get { return oilChange; }
            set { oilChange = value; onChange(); }
        }
        public bool LubeJob
        {
            get { return lubeJob; }
            set { lubeJob = value; onChange(); }
        }
        public bool Radiator
        {
            get { return radiator; }
            set { radiator = value; onChange(); }
        }
        public bool Transmission
        {
            get { return transmission; }
            set { transmission = value; onChange(); }
        }
        public bool Inspection
        {
            get { return inspection; }
            set { inspection = value; onChange(); }
        }
        public bool Muffler
        {
            get { return muffler; }
            set { muffler = value; onChange(); }
        }
        public bool Tire
        {
            get { return tire; }
            set { tire = value; onChange(); }
        }
        public bool OtherService
        {
            get { return otherService; }
            set { otherService = value; onChange(); }
        }
        public bool GridSelectVis
        {
            get { return gridSelectVis; }
            set { gridSelectVis = value; onChange(); }
        }
        public bool GridResultVis
        {
            get { return gridResultVis; }
            set { gridResultVis = value; onChange(); }
        }
        public string PartChargesVal
        {
            get { return partChargesVal; }
            set { partChargesVal = value; onChange(); }
        }
        public string PartTotalVal
        {
            get { return partTotalVal; }
            set { partTotalVal = value; onChange();}
        }
        public string LabourTotalVal
        {
            get { return labourTotalVal; }
            set { labourTotalVal = value; onChange(); }
        }

        public string OilLubeVal
        {
            get { return oilLubeVal; }
            set { oilLubeVal = value; onChange(); }
        }
        public string FlushChargesVal
        {
            get { return flushChargesVal; }
            set { flushChargesVal = value; onChange(); }
        }
        public string MiscChargesVal
        {
            get { return miscChargesVal; }
            set { miscChargesVal = value; onChange(); }
        }
        public string OtherChargesVal
        {
            get { return otherChargesVal; }
            set { otherChargesVal = value; onChange(); }
        }
        public string LabourVal
        {
            get { return labourVal; }
            set { labourVal = value; onChange(); }
        }
        public string LabourText
        {
            get { return labourText; }
            set { labourText = value; onChange(); }
        }
        public string TaxChargesVal
        {
            get { return taxChargesVal; }
            set { taxChargesVal = value; onChange(); }
        }
        public string TotalChargesVal
        {
            get { return totalChargesVal; }
            set { totalChargesVal = value; onChange(); }
        }
        public decimal PartCharges
        {
            get { return partCharges; }
            set { partCharges = value; onChange(); }
        }
        public int NoOfHours
        {
            get { return noOfHours; }
            set { noOfHours = value; onChange(); }
        }
        #endregion
        public void Calculate()
        {
            OilLubeVal = Math.Round(OilLubeCharges(), 2).ToString("C");
            FlushChargesVal = Math.Round(FlushCharges(), 2).ToString("C");
            MiscChargesVal = Math.Round(MiscCharges(), 2).ToString("C");
            OtherChargesVal = Math.Round(OtherCharges(), 2).ToString("C");
            TaxChargesVal = Math.Round(TaxCharges(), 2).ToString("C");
            TotalChargesVal = Math.Round(TotalCharges(), 2).ToString("C");
            PartChargesVal = Math.Round(PartCharges, 2).ToString("C") + " + " + TaxChargesVal;
            PartTotalVal = Math.Round((PartCharges + TaxCharges()), 2).ToString("C");
            GridResultVis = true;
            GridSelectVis = false;
            TitleHeight = SINGLE_HEIGHT;
            TitleWidth = SINGLE_WIDTH;
        }
        public decimal OilLubeCharges()
        {
            decimal total = 0;
            if (OilChange)
                total += (int)charges.OIL_CHARGES;
            if (LubeJob)
                total += (int)charges.LUBE_CHARGES;
            return total;
        }
        // Function to print Result grid
        public void Print(Grid gridResult)
        {
            try
            {
                PrintDialog printDlg = new PrintDialog();
                printDlg.PrintVisual(gridResult, "Joe's Automotive Bill");
            }
            catch (Exception)
            { }
        }
        public decimal FlushCharges()
        {
            decimal total = 0;
            if (Radiator)
                total += (int)charges.RADIATOR_CHARGES;
            if (Transmission)
                total += (int)charges.TRANSMISSION_CHARGES;
            return total;
        }
        public decimal MiscCharges()
        {
            decimal total = 0;
            if (Inspection)
                total += (int)charges.INSPECTION_CHARGES;
            if (Muffler)
                total += (int)charges.MUFFLER_CHARGES;
            if (Tire)
                total += (int)charges.TIRE_CHARGES;
            return total;
        }
        public decimal OtherCharges()
        {
            decimal total = 0;
            LabourText = Math.Round(total, 2).ToString("C");
            LabourTotalVal = Math.Round(total, 2).ToString("C");
            if (OtherService)
            {
                if (NoOfHours > 0)
                {
                    total = (((int)charges.LABOR_CHARGES) * NoOfHours);
                    LabourText = NoOfHours + "hr(s) x $" + (int)charges.LABOR_CHARGES;
                    LabourTotalVal = Math.Round(total, 2).ToString("C");
                }
                if (PartCharges > 0)
                    total += PartCharges + TaxCharges();
            }
            return total;
        }
        public decimal TaxCharges()
        {
            decimal taxes = 0;
            if (OtherService && (PartCharges > 0))
                taxes = PartCharges * TAX_RATE;
            return taxes;
        }
        public void Save()
        {
            try
            {
                string FileData = getData();
                SaveFileDialog saveFileDialog = new SaveFileDialog();
                if (saveFileDialog.ShowDialog() == true)
                {
                    File.AppendAllText(saveFileDialog.FileName, FileData + "\r\n");
                }
            }
            catch (Exception)
            { }
        }
        //Function to get data to save in file.
        private string getData()
        {
            string data = "";
            data = "Joe's Automotive Bill\r\n\r\n";
            data += "Oil Lube Charges   " + OilLubeVal + "\r\n";
            data += "Flush Charges      " + FlushChargesVal + "\r\n";
            data += "Misc Charges       " + MiscChargesVal + "\r\n";
            data += "Nonroutine Charges " + OtherChargesVal + "\r\n";
            data += "Total Charges      " + TotalChargesVal + "\r\n";
            return data;
        }
        public decimal TotalCharges()
        {
            decimal total = OilLubeCharges() + FlushCharges() + MiscCharges() + OtherCharges();
            return total;
        }
        public void ClearOilLube()
        {
            OilChange = false;
            LubeJob = false;
        }
        public void ClearFlushes()
        {
            Radiator = false;
            Transmission = false;
        }
        public void ClearMisc()
        {
            Inspection = false;
            Muffler = false;
            Tire = false;
        }
        public void ClearOther()
        {
            OtherService = false;
            NoOfHours = 0;
        }
        public void ClearTaxAndTotal()
        {
            PartTotalVal = "";
            PartCharges = 0;
        }
        public void ClearAll()
        {
            ClearOilLube();
            ClearFlushes();
            ClearMisc();
            ClearOther();
            ClearTaxAndTotal();
            GridResultVis = false;
            GridSelectVis = true;
            TitleHeight = DOUBLE_HEIGHT;
            TitleWidth = DOUBLE_WIDTH;
        }
        public void CheckOtherService()
        {
            OtherService = true;
        }

        #region PropertyChanged
        public event PropertyChangedEventHandler PropertyChanged;
        private void onChange([CallerMemberName] String propertyName = "")
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
        #endregion
    }
}
